# **Better Filesystem**

<img src="https://i.imgur.com/lEHFOv7.png" alt="Image Description" style="border-radius: 20px;">

**Better Filesystem** is an [Open Source](https://opensource.org/osd) Python Module which tries to make the Python Filesystem easier for Python users.

<span style="color:grey">*for the Documentation, you can check the [WIKI](https://github.com/mrgamernavshorts/better-filesystem/wiki) page.*</span>

Here is the [Github link for the repo](https://github.com/mrgamernavshorts/better-filesystem).